# ME449 Capstone Project
## Overshoot
- initial_config = np.array([-0.5, -0.5, 0.2,
                            0, -0.2, -0.6, -1.578, 0,
                            0, 0, 0, 0,
                            0])

- Kp = 10
- Ki = 0.01
- PI Control only, no Feedforward