# ME449 Capstone Project

## Without Collision
- initial_config = np.array([-0.5, -0.5, 0.2,
                            0, -0.2, -0.6, -1.578, 0,
                            0, 0, 0, 0,
                            0])
- Kp = 10
- Ki = 0.01
- Feedforward + PI controller
- Self-collision disabled
