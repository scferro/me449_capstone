# ME449 Capstone Project

## New Task
- initial_config = np.array([-0.5, -0.5, 0.2,
                            0, -0.2, -0.6, -1.578, 0,
                            0, 0, 0, 0,
                            0])
- Kp = 10
- Ki = 0.01
- Feedforward + PI controller

Tsc_init = np.array([[1, 0, 0, 1],
                    [0, 1, 0, 0],
                    [0, 0, 1, 0.025],
                    [0, 0, 0, 1]
                    ])
Tsc_final = np.array([[0, 1, 0, 0],
                    [-1, 0, 0, -3],
                    [0, 0, 1, 0.025],
                    [0, 0, 0, 1]
                    ])